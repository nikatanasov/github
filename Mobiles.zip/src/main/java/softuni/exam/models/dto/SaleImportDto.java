package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;

import javax.validation.constraints.Size;

public class SaleImportDto {

    @Expose
    private boolean discounted;

    @Expose
    private String number;

    @Expose
    private String saleDate;

    @Expose
    private int seller;

    public boolean isDiscounted() {
        return discounted;
    }

    public void setDiscounted(boolean discounted) {
        this.discounted = discounted;
    }

    public @Size(min = 7, max = 7) String getNumber() {
        return number;
    }

    public void setNumber(@Size(min = 7, max = 7) String number) {
        this.number = number;
    }

    public String getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(String saleDate) {
        this.saleDate = saleDate;
    }

    public int getSeller() {
        return seller;
    }

    public void setSeller(int seller) {
        this.seller = seller;
    }
}
