package softuni.exam.models.dto;

import javax.validation.constraints.Min;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "device")
@XmlAccessorType(XmlAccessType.FIELD)
public class DeviceImportDto {

    @XmlElement
    @Size(min = 2, max = 20)
    private String brand;

    @XmlElement(name = "device_type")
    private String deviceType;

    @XmlElement
    @Size(min = 1, max = 20)
    private String model;

    @XmlElement
    private double price;

    @XmlElement
    private int storage;

    @XmlElement
    @Min(1)
    private int saleId;

    public @Size(min = 2, max = 20) String getBrand() {
        return brand;
    }

    public void setBrand(@Size(min = 2, max = 20) String brand) {
        this.brand = brand;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public @Size(min = 1, max = 20) String getModel() {
        return model;
    }

    public void setModel(@Size(min = 1, max = 20) String model) {
        this.model = model;
    }

    @Positive
    public double getPrice() {
        return price;
    }

    public void setPrice(@Positive double price) {
        this.price = price;
    }

    @Positive
    public int getStorage() {
        return storage;
    }

    public void setStorage(@Positive int storage) {
        this.storage = storage;
    }

    public int getSaleId() {
        return saleId;
    }

    public void setSaleId(int saleId) {
        this.saleId = saleId;
    }
}
